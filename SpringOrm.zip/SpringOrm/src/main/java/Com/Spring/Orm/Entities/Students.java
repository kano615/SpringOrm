package Com.Spring.Orm.Entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student_details")
public class Students {
	@Id
	private int studentid;
	@Column(name="studentname")
	private String studentname;
	@Column(name="city")
	private String city;
	public Students() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Students(int studentid, String studentname, String city) {
		super();
		this.studentid = studentid;
		this.studentname = studentname;
		this.city = city;
	}
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Students [studentid=" + studentid + ", studentname=" + studentname + ", city=" + city + "]";
	}
}
