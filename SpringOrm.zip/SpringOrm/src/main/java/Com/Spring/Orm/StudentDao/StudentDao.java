package Com.Spring.Orm.StudentDao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.orm.hibernate5.HibernateTemplate;

import Com.Spring.Orm.Entities.Students;

public class StudentDao {
	private HibernateTemplate hibernateTemplate;

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	@Transactional
	public int insert(Students student) {
		Integer r = (Integer) this.hibernateTemplate.save(student);
		return r;
	}

	@Transactional
	public void delete(int studentid) {

		Students student = hibernateTemplate.get(Students.class, studentid);
        if (student != null) {
            hibernateTemplate.delete(student);
        }
	}

	@Transactional
	public void update(Students student) {
        this.hibernateTemplate.update(student);
	}

	@Transactional
	public Students getStudents(int studentid) {
		Students students = this.hibernateTemplate.get(Students.class, studentid);
		return students;

	}

	@Transactional
	public List<Students> getallStudents() {
		List<Students> students = this.hibernateTemplate.loadAll(Students.class);

		return students;
	}
}
