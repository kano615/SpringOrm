package Com.Spring.Orm;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import Com.Spring.Orm.Entities.Students;
import Com.Spring.Orm.StudentDao.StudentDao;

public class App {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Com/Spring/Orm/config.xml");
		StudentDao studentDao = context.getBean("StudentDao", StudentDao.class);
//       Students Students=new Students(2,"demo","rajkot");
//       int insert = studentDao.insert(Students);
//       System.out.println("done"+insert);

		boolean go = true;
		while (go) {
			try {
				BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));

				System.out.println("presss 1 for add student");
				System.out.println("presss 2 for displayall student");
				System.out.println("presss 3 for get single student");
				System.out.println("presss 4 for delete student");
				System.out.println("presss 5 for update student");
				System.out.println("presss 6 for exit!!");
				System.out.println("**********************************");
				System.out.println("Enter your Choice:");
				int choice = Integer.parseInt(bf.readLine());
				switch (choice) {
				case 1:
					System.out.println("enter studentid:");
					int id = Integer.parseInt(bf.readLine());

					System.out.println("enter Student name:");
					String name = bf.readLine();

					System.out.println("enter student city:");
					String city = bf.readLine();

					Students students = new Students();
					students.setStudentid(id);
					students.setStudentname(name);
					students.setCity(city);

					int insert = studentDao.insert(students);
					System.out.println("insert student" + insert);
					System.out.println("**********************************");
					break;

				case 2:

					List<Students> getallStudents = studentDao.getallStudents();
					System.out.println("List Display Off All Students");
					System.out.println("**********************************");
					for (Students s : getallStudents) {

						System.out.println(s.getStudentid());
						System.out.println(s.getStudentname());
						System.out.println(s.getCity());
						System.out.println("_________________________________________");
					}
					break;
				case 3:

					System.out.println("enter studentid:");
					int studentid = Integer.parseInt(bf.readLine());

					Students students2 = studentDao.getStudents(studentid);
					System.out.println("**********************************");
					System.out.println(students2.getStudentid());
					System.out.println(students2.getStudentname());
					System.out.println(students2.getCity());
					System.out.println("_________________________________________");

					break;
				case 4:

					System.out.println("enter studentid:");
					int studentid1 = Integer.parseInt(bf.readLine());
					

					studentDao.delete(studentid1);
					System.out.println("delete Student Successfully");
					System.out.println("**********************************");

					break;
				case 5:
					System.out.println("**********************************");
					System.out.println("enter studentid:");
					int id1 = Integer.parseInt(bf.readLine());
					System.out.println("enter Student name:");
					String name1 = bf.readLine();

					System.out.println("enter student city:");
					String city1 = bf.readLine();
					
					Students students1=new Students();
					students1.setStudentid(id1);
					students1.setStudentname(name1);
					students1.setCity(city1);
					
					studentDao.update(students1);
					System.out.println("**********************************");
					System.out.println("Student Updated Successfully");
					System.out.println("**********************************");
					
					break;
				case 6:
					go=false;
					break;
				}

			} catch (Exception e) {
				System.out.println("invalid input try with another");
				System.out.println(e.getMessage());
			}
		}
		System.out.println("Thank You To Use My Software");
		System.out.println("See you Soon");

	}
}
